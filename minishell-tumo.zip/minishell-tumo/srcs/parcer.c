#include "../includes/minishell.h"

void	test()
{
	printf("This shit works");
}
